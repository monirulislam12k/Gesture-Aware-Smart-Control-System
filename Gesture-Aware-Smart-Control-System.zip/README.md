# Gesture-Aware Smart Control System

A smart automation project built using Arduino UNO and ultrasonic sensing technology.  
The system detects hand proximity and reacts automatically using LED, buzzer, and relay control.

## Overview
This project uses an HC-SR04 Ultrasonic Sensor to measure distance and classify it into three zones:

| Distance Range | Action |
|----------------|---------|
| 0–10 cm | Motor/Light ON + LED ON + Buzzer ON |
| 11–20 cm | LED Warning ON |
| > 20 cm | All OFF (Idle mode) |

## Components
- Arduino UNO  
- HC-SR04 Ultrasonic Sensor  
- Relay Module  
- Buzzer (5V)  
- LED  
- 12V Motor / Light  
- Power Supply (5V + 12V)

## Wiring
| Arduino Pin | Component |
|--------------|------------|
| D9 | Ultrasonic TRIG |
| D8 | Ultrasonic ECHO |
| D7 | Relay IN |
| D6 | Buzzer |
| D5 | LED |
| 5V | Power (VCC) |
| GND | Common Ground |

## Author
**Md. Monirul Islam**
